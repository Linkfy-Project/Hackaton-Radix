---
title: Solar Panel Detector
emoji: 🌍
colorFrom: blue
colorTo: green
sdk: gradio
sdk_version: 4.10.0
app_file: app.py
pinned: false   
license: apache-2.0
---
For more details about the project: https://github.com/ArielDrabkin/Solar-Panel-Detector

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference